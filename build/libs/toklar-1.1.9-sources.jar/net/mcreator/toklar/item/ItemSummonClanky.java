package net.mcreator.toklar.item;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mcreator.toklar.entity.EntityMonster;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;

public class ItemSummonClanky extends Item {

    public ItemSummonClanky() {
        super();
        this.field_77777_bU = 1;
        this.func_77656_e(0);  // Optional: if you want it not to break
        this.func_77664_n();
        // Set creative tab if you want here, e.g.
        // this.setCreativeTab(CreativeTabs.MISC);
    }
    @GameRegistry.ObjectHolder("toklar:ghastly_potion")
    public static final Item item = null;

    @SideOnly(Side.CLIENT)
    public static void registerModels() {
        ModelLoader.setCustomModelResourceLocation(
            item, 0,
            new ModelResourceLocation("toklar:ghastly_potion", "inventory")
        );
    }

    @Override
    public String func_77653_i(ItemStack stack) {
        return "Ghastly Potion";
    }

    // Use the drink animation
    @Override
    public EnumAction func_77661_b(ItemStack stack) {
        return EnumAction.DRINK;
    }

    // How long to use (same as potion)
    @Override
    public int func_77626_a(ItemStack stack) {
        return 32;
    }

    // Called when right-clicked
    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        player.func_184598_c(hand);
        return super.func_77659_a(world, player, hand);
    }

    // Called when finished using (after 32 ticks of "drinking")
    @Override
    public ItemStack func_77654_b(ItemStack stack, World world, EntityLivingBase entity) {
        if (!world.field_72995_K && entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;

            // Summon boss near player
            EntityMonster.EntityCustom boss = new EntityMonster.EntityCustom(world);
            BlockPos pos = player.func_180425_c();
            boss.func_70107_b(pos.func_177958_n() + 1, pos.func_177956_o(), pos.func_177952_p() + 1);
            world.func_72838_d(boss);

            // Play summon sound
            world.func_184133_a(null, pos, SoundEvents.field_187855_gD, SoundCategory.HOSTILE, 1.0F, 1.0F);
        }

        if (entity instanceof EntityPlayer && !((EntityPlayer) entity).field_71075_bZ.field_75098_d) {
            stack.func_190918_g(1);
        }

        return stack;
    }
}
