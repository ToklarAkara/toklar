package net.mcreator.toklar;

import org.checkerframework.checker.units.qual.s;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.ByteBufUtils;

import net.minecraft.world.storage.WorldSavedData;
import net.minecraft.world.World;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.client.Minecraft;

public class ToklarVariables {
	public static class MapVariables extends WorldSavedData {
		public static final String DATA_NAME = "toklar_mapvars";
		public MapVariables() {
			super(DATA_NAME);
		}

		public MapVariables(String s) {
			super(s);
		}

		@Override
		public void func_76184_a(NBTTagCompound nbt) {
		}

		@Override
		public NBTTagCompound func_189551_b(NBTTagCompound nbt) {
			return nbt;
		}

		public void syncData(World world) {
			this.func_76185_a();
			if (world.field_72995_K) {
				Toklar.PACKET_HANDLER.sendToServer(new WorldSavedDataSyncMessage(0, this));
			} else {
				Toklar.PACKET_HANDLER.sendToAll(new WorldSavedDataSyncMessage(0, this));
			}
		}

		public static MapVariables get(World world) {
			MapVariables instance = (MapVariables) world.func_175693_T().func_75742_a(MapVariables.class, DATA_NAME);
			if (instance == null) {
				instance = new MapVariables();
				world.func_175693_T().func_75745_a(DATA_NAME, instance);
			}
			return instance;
		}
	}

	public static class WorldVariables extends WorldSavedData {
		public static final String DATA_NAME = "toklar_worldvars";
		public WorldVariables() {
			super(DATA_NAME);
		}

		public WorldVariables(String s) {
			super(s);
		}

		@Override
		public void func_76184_a(NBTTagCompound nbt) {
		}

		@Override
		public NBTTagCompound func_189551_b(NBTTagCompound nbt) {
			return nbt;
		}

		public void syncData(World world) {
			this.func_76185_a();
			if (world.field_72995_K) {
				Toklar.PACKET_HANDLER.sendToServer(new WorldSavedDataSyncMessage(1, this));
			} else {
				Toklar.PACKET_HANDLER.sendToDimension(new WorldSavedDataSyncMessage(1, this), world.field_73011_w.getDimension());
			}
		}

		public static WorldVariables get(World world) {
			WorldVariables instance = (WorldVariables) world.getPerWorldStorage().func_75742_a(WorldVariables.class, DATA_NAME);
			if (instance == null) {
				instance = new WorldVariables();
				world.getPerWorldStorage().func_75745_a(DATA_NAME, instance);
			}
			return instance;
		}
	}

	public static class WorldSavedDataSyncMessageHandler implements IMessageHandler<WorldSavedDataSyncMessage, IMessage> {
		@Override
		public IMessage onMessage(WorldSavedDataSyncMessage message, MessageContext context) {
			if (context.side == Side.SERVER)
				context.getServerHandler().field_147369_b.func_71121_q()
						.func_152344_a(() -> syncData(message, context, context.getServerHandler().field_147369_b.field_70170_p));
			else
				Minecraft.func_71410_x().func_152344_a(() -> syncData(message, context, Minecraft.func_71410_x().field_71439_g.field_70170_p));
			return null;
		}

		private void syncData(WorldSavedDataSyncMessage message, MessageContext context, World world) {
			if (context.side == Side.SERVER) {
				message.data.func_76185_a();
				if (message.type == 0)
					Toklar.PACKET_HANDLER.sendToAll(message);
				else
					Toklar.PACKET_HANDLER.sendToDimension(message, world.field_73011_w.getDimension());
			}
			if (message.type == 0) {
				world.func_175693_T().func_75745_a(MapVariables.DATA_NAME, message.data);
			} else {
				world.getPerWorldStorage().func_75745_a(WorldVariables.DATA_NAME, message.data);
			}
		}
	}

	public static class WorldSavedDataSyncMessage implements IMessage {
		public int type;
		public WorldSavedData data;
		public WorldSavedDataSyncMessage() {
		}

		public WorldSavedDataSyncMessage(int type, WorldSavedData data) {
			this.type = type;
			this.data = data;
		}

		@Override
		public void toBytes(io.netty.buffer.ByteBuf buf) {
			buf.writeInt(this.type);
			ByteBufUtils.writeTag(buf, this.data.func_189551_b(new NBTTagCompound()));
		}

		@Override
		public void fromBytes(io.netty.buffer.ByteBuf buf) {
			this.type = buf.readInt();
			if (this.type == 0)
				this.data = new MapVariables();
			else
				this.data = new WorldVariables();
			this.data.func_76184_a(ByteBufUtils.readTag(buf));
		}
	}
}
