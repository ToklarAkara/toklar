package net.mcreator.toklar.util;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

import java.util.HashMap;
import java.util.UUID;

public class FocusTracker {

    private static class FocusData {
        public EntityLivingBase target;
        public int focusLevel;
        public long timestamp;

        public FocusData(EntityLivingBase target, int focusLevel) {
            this.target = target;
            this.focusLevel = focusLevel;
            this.timestamp = System.currentTimeMillis();
        }

        public long getDurationMillis() {
        	return net.mcreator.toklar.enchantments.EnchantmentFocus.getFocusDurationMillis(focusLevel);
        }
    }

    private static final HashMap<UUID, FocusData> focusedTargets = new HashMap<>();

    // Old method kept for backward compatibility (focus level 1 assumed)
    public static void setFocusTarget(EntityPlayer player, EntityLivingBase target) {
        setFocusTarget(player, target, 1);
    }

    // New method with focus level
    public static void setFocusTarget(EntityPlayer player, EntityLivingBase target, int focusLevel) {
        focusedTargets.put(player.func_110124_au(), new FocusData(target, focusLevel));
    }

    public static EntityLivingBase getFocusTarget(EntityPlayer player) {
        FocusData data = focusedTargets.get(player.func_110124_au());
        if (data == null) {
            System.out.println("[FocusTracker] No focus data for player " + player.func_70005_c_());
            return null;
        }

        long elapsed = System.currentTimeMillis() - data.timestamp;
        if (elapsed > data.getDurationMillis()) {
            System.out.println("[FocusTracker] Focus expired for player " + player.func_70005_c_());
            focusedTargets.remove(player.func_110124_au());
            return null;
        }

        System.out.println("[FocusTracker] Player " + player.func_70005_c_() + " has active focus on " + data.target.func_70005_c_());
        return data.target;
    }

    // Optionally get focus level if needed
    public static int getFocusLevel(EntityPlayer player) {
        FocusData data = focusedTargets.get(player.func_110124_au());
        return (data != null) ? data.focusLevel : 0;
    }
}
