package net.mcreator.toklar.imbuement;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

/**
 * Handles weapon imbuement logic for Toklar.
 * Stores and applies multiple Lycanite debuffs via NBT.
 */
public class WeaponImbuementHandler {

    private static final String IMBUEMENT_TAG = "toklar_imbuement";

    public WeaponImbuementHandler() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    /**
     * Imbues the weapon with a Lycanite potion effect.
     * Adds to the effect list instead of overwriting.
     */
    public static void imbueWeapon(ItemStack weapon, String effectId, int durationTicks, int amplifier, String target) {
        if (weapon.func_190926_b()) return;

        System.out.println("[Toklar] Imbuing weapon with " + effectId + " (amp " + amplifier + ", dur " + durationTicks + ", target " + target + ")");

        NBTTagCompound tag = weapon.func_190925_c(IMBUEMENT_TAG);
        NBTTagList effectList = tag.func_150297_b("effects", 9) ? tag.func_150295_c("effects", 10) : new NBTTagList();

        NBTTagCompound singleEffect = new NBTTagCompound();
        singleEffect.func_74778_a("effect", effectId);
        singleEffect.func_74768_a("duration", durationTicks);
        singleEffect.func_74768_a("amplifier", amplifier);
        singleEffect.func_74778_a("target", target);

        effectList.func_74742_a(singleEffect);
        tag.func_74782_a("effects", effectList);
    }

    /**
     * Applies all imbuement effects to the correct entity.
     */
    public static void applyImbuementEffect(EntityLivingBase attacker, EntityLivingBase target, ItemStack weapon) {
        if (weapon.func_190926_b() || target == null) return;

        NBTTagCompound tag = weapon.func_77978_p();
        if (tag == null || !tag.func_74764_b(IMBUEMENT_TAG)) return;

        NBTTagCompound imbueData = tag.func_74775_l(IMBUEMENT_TAG);
        if (!imbueData.func_150297_b("effects", 9)) return;

        NBTTagList effectList = imbueData.func_150295_c("effects", 10);
        for (int i = 0; i < effectList.func_74745_c(); i++) {
            NBTTagCompound effectTag = effectList.func_150305_b(i);
            String effectId = effectTag.func_74779_i("effect");
            int duration = effectTag.func_74762_e("duration");
            int amplifier = effectTag.func_74762_e("amplifier");
            String targetKey = effectTag.func_74764_b("target") ? effectTag.func_74779_i("target") : "target";

            Potion potion = ForgeRegistries.POTIONS.getValue(new ResourceLocation(effectId));
            if (potion != null) {
                EntityLivingBase recipient = targetKey.equalsIgnoreCase("self") ? attacker : target;
                recipient.func_70690_d(new PotionEffect(potion, duration, amplifier));
            }
        }
    }

    /**
     * Event hook: applies imbuement effects on melee hit.
     */
    @SubscribeEvent
    public void onEntityHit(LivingHurtEvent event) {
        if (!(event.getSource().func_76346_g() instanceof EntityPlayer)) return;

        EntityPlayer attacker = (EntityPlayer) event.getSource().func_76346_g();
        ItemStack weapon = attacker.func_184614_ca();

        applyImbuementEffect(attacker, event.getEntityLiving(), weapon);
    }
}