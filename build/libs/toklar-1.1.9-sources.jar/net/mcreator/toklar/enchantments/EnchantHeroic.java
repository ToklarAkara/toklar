package net.mcreator.toklar.enchantments;

import com.mujmajnkraft.bettersurvival.items.ItemCustomWeapon;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import net.minecraft.enchantment.Enchantment.Rarity;

@Mod.EventBusSubscriber
public class EnchantHeroic extends Enchantment {

    public static EnchantHeroic INSTANCE;

    public EnchantHeroic() {
        super(Rarity.RARE, EnumEnchantmentType.ALL,
              new EntityEquipmentSlot[]{
                  EntityEquipmentSlot.MAINHAND,
                  EntityEquipmentSlot.OFFHAND,
                  EntityEquipmentSlot.HEAD,
                  EntityEquipmentSlot.CHEST
              });
        this.func_77322_b("heroic");
        INSTANCE = this;
    }

    @Override
    public int func_77325_b() {
        return 1; // only one rank
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return isValidItem(stack);
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return isValidItem(stack);
    }

    private boolean isValidItem(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemSword ||
               stack.func_77973_b() instanceof ItemShield ||
               stack.func_77973_b() instanceof ItemCustomWeapon ||
               (stack.func_77973_b() instanceof ItemArmor &&
                (((ItemArmor) stack.func_77973_b()).field_77881_a == EntityEquipmentSlot.HEAD ||
                 ((ItemArmor) stack.func_77973_b()).field_77881_a == EntityEquipmentSlot.CHEST));
    }

        @Override
    public boolean func_77326_a(Enchantment ench) {
        if (ench == null) return true; // prevent NPE
        return super.func_77326_a(ench) && ench != this;
    }

    // -----------------------------------------

    @SubscribeEvent
    public static void onEntityKill(LivingDeathEvent event) {
        if (!(event.getSource().func_76346_g() instanceof EntityPlayer)) return;
        if (!(event.getEntity() instanceof EntityLivingBase)) return;

        EntityPlayer attacker = (EntityPlayer) event.getSource().func_76346_g();
        EntityLivingBase target = (EntityLivingBase) event.getEntity();

        int pieces = 0;

        // Mainhand
        if (EnchantmentHelper.func_77506_a(INSTANCE, attacker.func_184614_ca()) > 0) {
            pieces++;
        }

        // Offhand
        if (EnchantmentHelper.func_77506_a(INSTANCE, attacker.func_184592_cb()) > 0) {
            pieces++;
        }

        // Helmet
        ItemStack helmet = attacker.func_184582_a(EntityEquipmentSlot.HEAD);
        if (!helmet.func_190926_b() && EnchantmentHelper.func_77506_a(INSTANCE, helmet) > 0) {
            pieces++;
        }

        // Chest
        ItemStack chest = attacker.func_184582_a(EntityEquipmentSlot.CHEST);
        if (!chest.func_190926_b() && EnchantmentHelper.func_77506_a(INSTANCE, chest) > 0) {
            pieces++;
        }

        if (pieces <= 0) return;

        // Cap at 3 pieces max
        pieces = Math.min(pieces, 3);

        // Base heal: 5% of target HP, minimum 1
        int baseHeal = (int) Math.max(Math.floor(target.func_110138_aP() * 0.05F), 1.0D);

        // Flat bonus: +1 per enchanted piece (capped at 3)
        int restore = baseHeal + pieces;

        // Cap total heal at 20 HP (10 hearts)
        restore = Math.min(restore, 20);

        if (restore > 0 && attacker.func_110143_aJ() < attacker.func_110138_aP()) {
            attacker.func_70691_i(restore);
            attacker.field_70170_p.func_175718_b(2007, attacker.func_180425_c(), 0); // heart particles
        }
    }
}