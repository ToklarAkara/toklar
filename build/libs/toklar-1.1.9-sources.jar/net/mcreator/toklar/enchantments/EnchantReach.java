package net.mcreator.toklar.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import net.minecraft.enchantment.Enchantment.Rarity;

@Mod.EventBusSubscriber
public class EnchantReach extends Enchantment {

    private static final String NBT_REACH_ON = "reachon";
    private static final String NBT_ORIGINAL_REACH = "reach_original";
    private static final String NBT_LAST_APPLIED = "reach_last_applied";
    private static final double EPS = 1.0e-6;

    public static EnchantReach INSTANCE;

    public EnchantReach() {
        super(Rarity.VERY_RARE, EnumEnchantmentType.ARMOR_CHEST,
              new EntityEquipmentSlot[]{EntityEquipmentSlot.CHEST});
        this.func_77322_b("block_reach");
        INSTANCE = this;
    }

    @Override
    public int func_77325_b() {
        return 1;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemArmor &&
               ((ItemArmor) stack.func_77973_b()).field_77881_a == EntityEquipmentSlot.CHEST;
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return func_92089_a(stack);
    }

    private static boolean approxEq(double a, double b) {
        return Math.abs(a - b) <= EPS;
    }

    private static void applyOrMaintain(EntityPlayer player) {
        if (player.field_70170_p.field_72995_K) return;

        IAttributeInstance reachAttr = player.func_110140_aT().func_111152_a("generic.reachDistance");
        if (reachAttr == null) return;

        boolean active = player.getEntityData().func_74767_n(NBT_REACH_ON);
        double currentBase = reachAttr.func_111125_b();
        double lastApplied = player.getEntityData().func_74764_b(NBT_LAST_APPLIED)
                ? player.getEntityData().func_74769_h(NBT_LAST_APPLIED) : -1.0;

        if (!active) {
            // First-time equip: save underlying base and double once.
            player.getEntityData().func_74780_a(NBT_ORIGINAL_REACH, currentBase);
            double newBase = currentBase * 2.0;
            reachAttr.func_111128_a(newBase);
            player.getEntityData().func_74780_a(NBT_LAST_APPLIED, newBase);
            player.getEntityData().func_74757_a(NBT_REACH_ON, true);
            System.out.println("[ReachEnchant] Applied: orig=" + currentBase + " new=" + newBase);
            return;
        }

        // Already active:
        // If the base equals the last value we applied, do nothing (stable).
        if (approxEq(currentBase, lastApplied)) {
            return;
        }

        // External change detected (race/other mod changed base).
        // Treat the current base as the new underlying base and reapply doubling exactly once.
        double newUnderlying = currentBase;
        double newBase = newUnderlying * 2.0;
        reachAttr.func_111128_a(newBase);
        player.getEntityData().func_74780_a(NBT_ORIGINAL_REACH, newUnderlying);
        player.getEntityData().func_74780_a(NBT_LAST_APPLIED, newBase);
        System.out.println("[ReachEnchant] Reapplied after external change: newOrig=" + newUnderlying + " new=" + newBase);
    }

    private static void removeSafely(EntityPlayer player) {
        if (player.field_70170_p.field_72995_K) return;

        IAttributeInstance reachAttr = player.func_110140_aT().func_111152_a("generic.reachDistance");
        if (reachAttr == null) return;

        boolean active = player.getEntityData().func_74767_n(NBT_REACH_ON);
        if (!active) return;

        double savedOrig = player.getEntityData().func_74764_b(NBT_ORIGINAL_REACH)
                ? player.getEntityData().func_74769_h(NBT_ORIGINAL_REACH) : -1.0;
        double lastApplied = player.getEntityData().func_74764_b(NBT_LAST_APPLIED)
                ? player.getEntityData().func_74769_h(NBT_LAST_APPLIED) : -1.0;
        double currentBase = reachAttr.func_111125_b();

        // Only restore if we still see our last applied value; otherwise, don't clobber external updates.
        if (lastApplied > 0 && approxEq(currentBase, lastApplied) && savedOrig > 0) {
            reachAttr.func_111128_a(savedOrig);
            System.out.println("[ReachEnchant] Removed: restored=" + savedOrig);
        } else {
            System.out.println("[ReachEnchant] Removed: skipped restore (external change). currentBase=" +
                    currentBase + " lastApplied=" + lastApplied + " savedOrig=" + savedOrig);
        }

        player.getEntityData().func_74757_a(NBT_REACH_ON, false);
        player.getEntityData().func_82580_o(NBT_LAST_APPLIED);
        player.getEntityData().func_82580_o(NBT_ORIGINAL_REACH);
    }

    @SubscribeEvent
    public static void onEntityUpdate(LivingUpdateEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;

        EntityPlayer player = (EntityPlayer) event.getEntityLiving();
        ItemStack armor = player.func_184582_a(EntityEquipmentSlot.CHEST);

        int level = 0;
        if (!armor.func_190926_b() &&
            EnchantmentHelper.func_82781_a(armor) != null &&
            EnchantmentHelper.func_82781_a(armor).containsKey(INSTANCE)) {
            level = EnchantmentHelper.func_82781_a(armor).get(INSTANCE);
        }

        if (level > 0) {
            applyOrMaintain(player);
        } else if (player.getEntityData().func_74767_n(NBT_REACH_ON)) {
            removeSafely(player);
        }
    }
}