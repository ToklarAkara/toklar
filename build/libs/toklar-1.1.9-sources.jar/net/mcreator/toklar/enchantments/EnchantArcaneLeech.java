package net.mcreator.toklar.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import net.minecraft.enchantment.Enchantment.Rarity;

@Mod.EventBusSubscriber
public class EnchantArcaneLeech extends Enchantment {

    public static EnchantArcaneLeech INSTANCE;

    public EnchantArcaneLeech() {
        super(Rarity.RARE, EnumEnchantmentType.WEAPON,
              new EntityEquipmentSlot[]{EntityEquipmentSlot.MAINHAND, EntityEquipmentSlot.OFFHAND});
        this.func_77322_b("arcane_leech");
        INSTANCE = this;
    }
    @Override
    public boolean func_77326_a(Enchantment ench) {
        if (ench == null) return true; // prevent NPE
        return super.func_77326_a(ench) && ench != this;
    }


    @Override
    public int func_77325_b() {
        return 3; // same scaling as Lifesteal
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return this.field_77351_y.func_77557_a(stack.func_77973_b());
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return this.field_77351_y.func_77557_a(stack.func_77973_b());
    }

    @SubscribeEvent(priority = net.minecraftforge.fml.common.eventhandler.EventPriority.LOW)
    public static void onLivingHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();
        if (source == null) return;

        // Only trigger on magic or indirectMagic damage
        String type = source.field_76373_n;
        if (!"magic".equals(type) && !"indirectMagic".equals(type)) return;

        if (!(source.func_76346_g() instanceof EntityLivingBase)) return;
        EntityLivingBase attacker = (EntityLivingBase) source.func_76346_g();
        if (attacker == null) return;

        // Check mainhand and offhand for the enchantment
        int level = Math.max(
            EnchantmentHelper.func_77506_a(INSTANCE, attacker.func_184614_ca()),
            EnchantmentHelper.func_77506_a(INSTANCE, attacker.func_184592_cb())
        );
        if (level <= 0) return;

        if (event.getAmount() <= 1.0F) return; // ignore tiny chip damage

        // Heal: 3% of damage per level (same as Lifesteal)
        float heal = event.getAmount() * 0.03F * level;
        if (heal > 0) {
            attacker.func_70691_i(heal);
            attacker.field_70170_p.func_175718_b(2007, attacker.func_180425_c(), 0); // heart particles
        }
    }
}