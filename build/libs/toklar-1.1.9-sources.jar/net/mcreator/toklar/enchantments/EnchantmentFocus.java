package net.mcreator.toklar.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.mcreator.toklar.config.ModConfig;


import net.minecraft.enchantment.Enchantment.Rarity;

public class EnchantmentFocus extends Enchantment {

	public EnchantmentFocus() {
	    super(Rarity.UNCOMMON, null, new EntityEquipmentSlot[]{EntityEquipmentSlot.MAINHAND});
	    this.func_77322_b("focus");
	    // Remove setRegistryName here — it's handled in EnchantmentInit
	}
    @Override
    public boolean func_77326_a(Enchantment ench) {
        if (ench == null) return true; // prevent NPE from Anvil Patch
        return super.func_77326_a(ench) && ench != this;
    }
    @Override
    public int func_77321_a(int level) {
        return 10 + (level - 1) * 15;
    }

    @Override
    public int func_77317_b(int level) {
        return func_77321_a(level) + 20;
    }

    @Override
    public int func_77325_b() {
        return 3;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        // Only allow if the item is enchantable AND not armor
        return stack.func_77973_b().func_77616_k(stack)
            && !(stack.func_77973_b() instanceof ItemArmor);
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return func_92089_a(stack);
    }

    @Override
    public boolean isAllowedOnBooks() {
        return true;
    }

    /** Returns bonus damage multiplier. Example: 0.10f = 10% */
    public static float getBonusDamageMultiplier(int level) {
        return ModConfig.getFocusBonusDamagePerLevel() * level;
    }

    /** Returns focus duration in milliseconds */
    public static long getFocusDurationMillis(int level) {
        return (long)(ModConfig.getFocusDurationSecondsPerLevel() * 1000L * level);
    }

    @Override
    public String func_77320_a() {
        return "enchantment.toklar.focus";
    }

}
