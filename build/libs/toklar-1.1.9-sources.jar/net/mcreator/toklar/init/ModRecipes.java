package net.mcreator.toklar.init;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraft.item.crafting.Ingredient;
import net.mcreator.toklar.init.ModBlocks;

public class ModRecipes {
    public static void init() {
        GameRegistry.addShapedRecipe(
            new ResourceLocation("toklar", "imbuement_altar"),
            null,
            new ItemStack(ModBlocks.IMBUEMENT_ALTAR),
            "SSS", "SXS", "SSS",
            'S', Ingredient.func_193368_a(
                Item.func_111206_d("lycanitesmobs:ashenstone"),
                Item.func_111206_d("lycanitesmobs:lushstone"),
                Item.func_111206_d("lycanitesmobs:demonstone"),
                Item.func_111206_d("lycanitesmobs:aberrantstone"),
                Item.func_111206_d("lycanitesmobs:streamstone"),
                Item.func_111206_d("lycanitesmobs:desertstone"),
                Item.func_111206_d("lycanitesmobs:shadowstone"),
                Item.func_111206_d("lycanitesmobs:saltstone"),
                Item.func_111206_d("lycanitesmobs:freshwaterstone"),
                Item.func_111206_d("lycanitesmobs:mountainstone"),
                Item.func_111206_d("lycanitesmobs:foreststone"),
                Item.func_111206_d("lycanitesmobs:infernostone"),
                Item.func_111206_d("lycanitesmobs:swampstone"),
                Item.func_111206_d("lycanitesmobs:junglestone"),
                Item.func_111206_d("lycanitesmobs:plainsstone"),
                Item.func_111206_d("lycanitesmobs:voidstone"),
                Item.func_111206_d("lycanitesmobs:bloodstone"),
                Item.func_111206_d("lycanitesmobs:darkstone")
            ),
            'X', Ingredient.func_193368_a(Item.func_111206_d("lycanitesmobs:soulstone"))
        );
    }
}