package net.mcreator.toklar;

import com.lycanitesmobs.core.entity.damagesources.MinionEntityDamageSource;
import com.lycanitesmobs.core.entity.damagesources.ElementDamageSource;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityOwnable;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import electroblob.wizardry.entity.living.EntitySummonedCreature;
import net.mcreator.toklar.config.ModConfig;
import net.mcreator.toklar.item.ItemBronzeArmor;
import net.mcreator.toklar.item.ItemToklarArmor;

import com.windanesz.wizardryutils.capability.SummonedCreatureData;
import xzeroair.trinkets.api.EntityApiHelper;

import java.util.UUID;

@Mod.EventBusSubscriber
public class SummonDamageBuffHandler {

    private static void debugLog(String message) {
        if (ModConfig.enableSummonDamageBuffDebug) {
            System.out.println("[SummonDamageBuff] " + message);
        }
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();

        Entity immediateSource = source.func_76364_f();
        Entity trueSource = source.func_76346_g();

        debugLog("Immediate source class: " + (immediateSource != null ? immediateSource.getClass().getName() : "null"));
        debugLog("True source class: " + (trueSource != null ? trueSource.getClass().getName() : "null"));

        EntityLivingBase attackerEntity = null;
        EntityPlayer owner = null;

        if (immediateSource instanceof EntityArrow) {
            EntityArrow arrow = (EntityArrow) immediateSource;
            Entity shooter = arrow.field_70250_c;

            if (shooter instanceof EntitySummonedCreature) {
                EntitySummonedCreature summonedShooter = (EntitySummonedCreature) shooter;
                owner = getOwnerFromEntity(summonedShooter);
                if (owner != null) {
                    attackerEntity = summonedShooter;
                    debugLog("Arrow shot by summoned creature owned by player: " + owner.func_70005_c_());
                }
            } else if (shooter instanceof EntityLivingBase) {
                attackerEntity = (EntityLivingBase) shooter;
                owner = getOwnerFromEntity((EntityLivingBase) shooter);
                if (owner != null) {
                    debugLog("Arrow shot by summon owned by player: " + owner.func_70005_c_());
                }
            }
        }

        if (attackerEntity == null) {
            if (immediateSource instanceof EntityLivingBase) {
                attackerEntity = (EntityLivingBase) immediateSource;
            } else if (trueSource instanceof EntityLivingBase) {
                attackerEntity = (EntityLivingBase) trueSource;
            } else {
                debugLog("No valid living attacker found.");
                return;
            }
        }

        if (attackerEntity instanceof EntityPlayer && !(immediateSource instanceof EntitySummonedCreature)) {
            EntityPlayer playerAttacker = (EntityPlayer) attackerEntity;
            debugLog("Damage caused directly by player: " + playerAttacker.func_70005_c_() + ", no buff applied.");
            return;
        }

        if (attackerEntity instanceof EntityPlayer) {
            if (immediateSource instanceof EntitySummonedCreature) {
                EntitySummonedCreature summoned = (EntitySummonedCreature) immediateSource;
                UUID casterUUID = getCasterUUIDFromSummoned(summoned);
                if (casterUUID != null && casterUUID.equals(attackerEntity.func_110124_au())) {
                    owner = (EntityPlayer) attackerEntity;
                    attackerEntity = summoned;
                    debugLog("Damage caused by summoned creature owned by player: " + owner.func_70005_c_());
                } else {
                    owner = (EntityPlayer) attackerEntity;
                    debugLog("Damage caused directly by player: " + owner.func_70005_c_());
                }
            } else {
                owner = (EntityPlayer) attackerEntity;
                debugLog("Damage caused directly by player: " + owner.func_70005_c_());
            }
        } else {
            owner = getOwnerFromEntity(attackerEntity);
            if (owner == null) {
                debugLog("Could not find owner of attacker entity. Dumping NBT:");
                debugPrintNBT(attackerEntity.getEntityData(), "");
                return;
            }
            debugLog("Owner found: " + owner.func_70005_c_());
        }

        debugArmorCheck(owner);

        if (!isHuman(owner)) {
            debugLog("Player is not human, no summon buff applied.");
            return;
        }

        if (isWearingFullBronzeSet(owner)) {
            float oldDamage = event.getAmount();
            float multiplier = ModConfig.getSummonDamageMultiplier();
            float newDamage = oldDamage * multiplier;
            event.setAmount(newDamage);
            debugLog(String.format("Damage boosted from %.2f to %.2f for owner %s with bronze multiplier %.2f",
                    oldDamage, newDamage, owner.func_70005_c_(), multiplier));
        } else if (isWearingFullToklarSet(owner)) {
            float oldDamage = event.getAmount();
            float multiplier = ModConfig.getToklarSummonDamageMultiplier();
            float newDamage = oldDamage * multiplier;
            event.setAmount(newDamage);
            debugLog(String.format("Damage boosted from %.2f to %.2f for owner %s with toklar multiplier %.2f",
                    oldDamage, newDamage, owner.func_70005_c_(), multiplier));
        } else {
            debugLog("Owner not wearing full bronze or toklar set");
        }
    }

    private static boolean isHuman(EntityPlayer player) {
        String race = EntityApiHelper.getEntityRace(player);
        debugLog("Player race: " + race);
        return "none".equalsIgnoreCase(race);
    }

    private static UUID getCasterUUIDFromSummoned(EntitySummonedCreature summoned) {
        try {
            java.lang.reflect.Field field = EntitySummonedCreature.class.getDeclaredField("casterUUID");
            field.setAccessible(true);
            return (UUID) field.get(summoned);
        } catch (Exception e) {
            debugLog("Failed to get casterUUID: " + e.getMessage());
            return null;
        }
    }

    public static EntityPlayer getOwnerFromEntity(EntityLivingBase entity) {
        debugLog("Attacker class: " + entity.getClass().getName());

        NBTTagCompound nbt = entity.getEntityData();
        SummonedCreatureData data = SummonedCreatureData.get(entity);
        if (data != null) {
            EntityLivingBase caster = data.getCaster();
            if (caster instanceof EntityPlayer) {
                debugLog("Owner found via SummonedCreatureData.getCaster()");
                return (EntityPlayer) caster;
            }
        }

        if (entity instanceof IEntityOwnable) {
            Entity owner = ((IEntityOwnable) entity).func_70902_q();
            if (owner instanceof EntityPlayer) {
                debugLog("Owner found via IEntityOwnable");
                return (EntityPlayer) owner;
            }
        }

        if (entity instanceof EntitySummonedCreature) {
            EntityLivingBase caster = ((EntitySummonedCreature) entity).getCaster();
            if (caster instanceof EntityPlayer) {
                debugLog("Owner found via EntitySummonedCreature.getCaster()");
                return (EntityPlayer) caster;
            }
        }

        if (nbt.func_150297_b("wizardryutils:summonedcreaturedata", 10)) {
            NBTTagCompound summonData = nbt.func_74775_l("wizardryutils:summonedcreaturedata");
            if (summonData.func_150297_b("casterUUID", 10)) {
                NBTTagCompound casterUUIDTag = summonData.func_74775_l("casterUUID");
                if (casterUUIDTag.func_74764_b("casterUUIDMost") && casterUUIDTag.func_74764_b("casterUUIDLeast")) {
                    long most = casterUUIDTag.func_74763_f("casterUUIDMost");
                    long least = casterUUIDTag.func_74763_f("casterUUIDLeast");
                    UUID ownerId = new UUID(most, least);
                    EntityPlayer owner = entity.field_70170_p.func_152378_a(ownerId);
                    if (owner != null) {
                        debugLog("Owner found via wizardryutils compound tag");
                        return owner;
                    }
                }
            }
        }

        String[] uuidKeys = {"OwnerId", "ownerUUIDMost", "ownerUUIDLeast", "OwnerUUIDMost", "OwnerUUIDLeast"};
        for (String key : uuidKeys) {
            if (nbt.func_74764_b(key)) {
                try {
                    UUID ownerId;
                    if (key.equals("OwnerId")) {
                        ownerId = UUID.fromString(nbt.func_74779_i(key));
                    } else {
                        long most = nbt.func_74763_f(key.contains("Most") ? key : key.replace("Least", "Most"));
                        long least = nbt.func_74763_f(key.contains("Least") ? key : key.replace("Most", "Least"));
                        ownerId = new UUID(most, least);
                    }
                    EntityPlayer owner = entity.field_70170_p.func_152378_a(ownerId);
                    if (owner != null) {
                        debugLog("Owner found via NBT: " + key);
                        return owner;
                    }
                } catch (Exception e) {
                    debugLog("Failed to parse UUID from NBT key: " + key);
                }
            }
        }

        debugLog("No owner could be found");
        return null;
    }

    private static void debugPrintNBT(NBTTagCompound compound, String prefix) {
        for (String key : compound.func_150296_c()) {
            NBTBase value = compound.func_74781_a(key);
            debugLog(prefix + key + ": " + value);
            if (value instanceof NBTTagCompound) {
                debugPrintNBT((NBTTagCompound) value, prefix + key + ".");
            }
        }
    }

    private static void debugArmorCheck(EntityPlayer player) {
        debugLog("Checking armor:");
        debugLog("Helmet equipped: " + player.func_184582_a(EntityEquipmentSlot.HEAD));
        debugLog("Expected bronze helmet item: " + ItemBronzeArmor.helmet);
        debugLog("Expected toklar helmet item: " + ItemToklarArmor.helmet);
        debugLog("Chest equipped: " + player.func_184582_a(EntityEquipmentSlot.CHEST));
        debugLog("Expected bronze chest item: " + ItemBronzeArmor.body);
        debugLog("Expected toklar chest item: " + ItemToklarArmor.body);
        debugLog("Legs equipped: " + player.func_184582_a(EntityEquipmentSlot.LEGS));
        debugLog("Expected bronze legs item: " + ItemBronzeArmor.legs);
        debugLog("Expected toklar legs item: " + ItemToklarArmor.legs);
        debugLog("Boots equipped: " + player.func_184582_a(EntityEquipmentSlot.FEET));
        debugLog("Expected bronze boots item: " + ItemBronzeArmor.boots);
        debugLog("Expected toklar boots item: " + ItemToklarArmor.boots);
    }

    private static boolean isWearingFullBronzeSet(EntityPlayer player) {
        return isMatching(ItemBronzeArmor.helmet, player.func_184582_a(EntityEquipmentSlot.HEAD)) &&
               isMatching(ItemBronzeArmor.body, player.func_184582_a(EntityEquipmentSlot.CHEST)) &&
               isMatching(ItemBronzeArmor.legs, player.func_184582_a(EntityEquipmentSlot.LEGS)) &&
               isMatching(ItemBronzeArmor.boots, player.func_184582_a(EntityEquipmentSlot.FEET));
    }

    private static boolean isWearingFullToklarSet(EntityPlayer player) {
        return isMatching(ItemToklarArmor.helmet, player.func_184582_a(EntityEquipmentSlot.HEAD)) &&
               isMatching(ItemToklarArmor.body, player.func_184582_a(EntityEquipmentSlot.CHEST)) &&
               isMatching(ItemToklarArmor.legs, player.func_184582_a(EntityEquipmentSlot.LEGS)) &&
               isMatching(ItemToklarArmor.boots, player.func_184582_a(EntityEquipmentSlot.FEET));
    }

    private static boolean isMatching(Item expectedItem, ItemStack worn) {
        return worn != null && !worn.func_190926_b() && worn.func_77973_b() == expectedItem;
    }
}
