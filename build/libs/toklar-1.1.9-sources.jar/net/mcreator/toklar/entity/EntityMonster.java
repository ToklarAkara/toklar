package net.mcreator.toklar.entity;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelBox;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.init.SoundEvents;
import java.util.List;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTable;
import net.mcreator.toklar.ElementsToklar;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import com.tmtravlr.potioncore.PotionCoreAttributes;
import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;

@ElementsToklar.ModElement.Tag
public class EntityMonster extends ElementsToklar.ModElement {
    public static final int ENTITYID = 3;

    public EntityMonster(ElementsToklar instance) {
        super(instance, 4);
    }

    @Override
    public void initElements() {
        elements.entities.add(() -> EntityEntryBuilder.create()
                .entity(EntityCustom.class)
                .id(new ResourceLocation("toklar", "monster"), ENTITYID)
                .name("monster")
                .tracker(64, 3, true)
                .egg(-1, -1)
                .build());
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void preInit(FMLPreInitializationEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(EntityCustom.class, renderManager -> new RenderLiving<EntityCustom>(
                renderManager, new Modeltoklar1(), 0.5f) {
            @Override
            protected ResourceLocation func_110775_a(EntityCustom entity) {
                return new ResourceLocation("toklar:textures/toklar1.png");
            }
        });
    }

    public static class EntityCustom extends EntityMob {
        // Explicit constructor calling super(world)
        public EntityCustom(World world) {
            super(world);
            func_70105_a(0.9f, 1.9f); // standard size
            field_70728_aV = 50;
            this.field_70178_ae = false;
            func_94061_f(false);
            func_110163_bv();
        }

        public ITextComponent func_145748_c_() {
            return new TextComponentString("Clanky");
        }

        @Override
        protected int func_70693_a(EntityPlayer player) {
            return 18487; // Enough raw XP to give 100 levels
        }

        @Override
        public void func_70071_h_() {
            super.func_70071_h_();

            // Vortex trigger: check if mid-air and has a target
            if (!this.field_70122_E && this.func_70638_az() != null && this.field_70181_x > 0) {
                List<EntityPlayer> players = this.field_70170_p.func_72872_a(EntityPlayer.class,
                        this.func_174813_aQ().func_186662_g(15.0D)); // 15-block radius

                for (EntityPlayer player : players) {
                    if (player.func_184812_l_() || player.func_175149_v()) continue;

                    double dx = this.field_70165_t - player.field_70165_t;
                    double dy = this.field_70163_u - player.field_70163_u;
                    double dz = this.field_70161_v - player.field_70161_v;
                    double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (dist < 0.1) dist = 0.1;

                    double strength = 3.5D; // high-impact pull
                    player.field_70159_w += (dx / dist) * strength;
                    player.field_70181_x += (dy / dist) * strength * 0.5;
                    player.field_70179_y += (dz / dist) * strength;
                    player.field_70133_I = true;


                    // Apply Slowness only if not already active
                    if (!player.func_70644_a(MobEffects.field_76421_d)) {
                        player.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 60, 1)); // 3s, level 2
                    }

                    // Spawn vortex particles
                    for (int i = 0; i < 6; i++) {
                        double px = player.field_70165_t + (this.field_70146_Z.nextDouble() - 0.5D) * 2.0D;
                        double py = player.field_70163_u + this.field_70146_Z.nextDouble() * 2.0D;
                        double pz = player.field_70161_v + (this.field_70146_Z.nextDouble() - 0.5D) * 2.0D;
                        this.field_70170_p.func_175688_a(EnumParticleTypes.PORTAL, px, py, pz, 0.0D, 0.1D, 0.0D);
                    }

                    // Play vortex sound
                    this.field_70170_p.func_184148_a(null, this.field_70165_t, this.field_70163_u, this.field_70161_v,
                        SoundEvents.field_187689_f, this.func_184176_by(), 1.0F, 1.0F);
                }
            }
        
        }
        @Override
        public boolean func_70687_e(PotionEffect effect) {
        	if (effect.func_188419_a() == MobEffects.field_76421_d ||
        		    effect.func_188419_a() == MobEffects.field_76437_t ||
        		    effect.func_188419_a() == MobEffects.field_76419_f) {
        		    return false;
        		}
            return super.func_70687_e(effect);
        }
        
        @Override
        protected void func_184651_r() {
            this.field_70714_bg.func_75776_a(0, new EntityAISwimming(this));
            this.field_70714_bg.func_75776_a(1, new EntityAILeapAtTarget(this, 0.6F)); // stronger leap
            this.field_70714_bg.func_75776_a(2, new EntityAIAttackMelee(this, 1.2D, true));
            this.field_70714_bg.func_75776_a(3, new EntityAIWander(this, 1.0D));
            this.field_70714_bg.func_75776_a(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
            this.field_70714_bg.func_75776_a(5, new EntityAILookIdle(this));
            this.field_70715_bh.func_75776_a(1, new EntityAIHurtByTarget(this, false));
            this.field_70715_bh.func_75776_a(2, new EntityAINearestAttackableTarget<>(this, EntityPlayer.class, true));
        }

        @Override
        protected void func_110147_ax() {
            super.func_110147_ax();
            this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(6666.0D);
            this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.35D);
            this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(15.0D); // Stronger than Wither
            this.func_110148_a(SharedMonsterAttributes.field_188791_g).func_111128_a(20.0D); // max armor
            this.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111128_a(8.0D); // max toughness
            this.func_110148_a(PotionCoreAttributes.MAGIC_SHIELDING).func_111128_a(0.80D);
            this.func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(1.0D);
        }

        @Override
        protected boolean func_70692_ba() {
            return false;
        }

        // New loot drop from loot table
        @Override
        protected ResourceLocation func_184647_J() {
            return new ResourceLocation("toklar", "entities/clanky");
        }
        

        @Override
        public boolean func_70097_a(DamageSource source, float amount) {
            Entity attacker = source.func_76346_g();

            if (attacker instanceof EntityLivingBase) {
                double distance = this.func_70032_d(attacker);

                if (distance > 16.0D) {
                        this.field_70170_p.func_184148_a(null, this.field_70165_t, this.field_70163_u, this.field_70161_v,
                        SoundEvents.field_187689_f, this.func_184176_by(), 1.0F, 1.0F);

                    return false; // Cancel damage
                }
            }

            return super.func_70097_a(source, amount);
        }
        
        @Override
        public EnumCreatureAttribute func_70668_bt() {
            return EnumCreatureAttribute.UNDEFINED;
        }

        @Override
        protected SoundEvent func_184639_G() {
            return SoundEvents.field_187899_gZ;
        }

        @Override
        protected SoundEvent func_184601_bQ(DamageSource source) {
            return SoundEvents.field_187543_bD;
        }

        @Override
        protected SoundEvent func_184615_bR() {
            return SoundEvents.field_187661_by;
        }

        @Override
        protected float func_70599_aP() {
            return 1.0F;
        }
    }

    public static class Modeltoklar1 extends ModelBase {
        private final ModelRenderer armorHead;
        private final ModelRenderer cube_r1;
        private final ModelRenderer cube_r2;
        private final ModelRenderer armorBody;
        private final ModelRenderer armorLeftArm;
        private final ModelRenderer armorRightArm;
        private final ModelRenderer armorLeftLeg;
        private final ModelRenderer armorRightLeg;
        private final ModelRenderer armorLeftBoot;
        private final ModelRenderer armorRightBoot;

        public Modeltoklar1() {
            this.field_78090_t = 128;
            this.field_78089_u = 128;
            this.armorHead = new ModelRenderer(this);
            this.armorHead.func_78793_a(0.0F, 0.0F, 0.0F);
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 0, 0, -5.0F, -9.0F, -5.0F, 10, 1, 10, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 0, 12, -4.0F, -10.0F, -4.0F, 8, 1, 8, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 25, 37, -5.0F, -8.0F, -5.0F, 1, 8, 9, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 33, 3, 4.0F, -8.0F, -5.0F, 1, 8, 9, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 31, 0, -4.0F, -8.0F, -5.0F, 8, 1, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 0, 12, -1.0F, -7.0F, -5.0F, 2, 3, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 0, 51, -5.0F, -8.0F, 4.0F, 10, 8, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 47, 61, -2.0F, -4.0F, -5.0F, 4, 1, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 46, 45, 2.0F, -1.0F, -5.0F, 2, 1, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 0, 17, -4.0F, -1.0F, -5.0F, 2, 1, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 52, 23, 3.0F, -2.0F, -5.0F, 1, 1, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 46, 48, -4.0F, -2.0F, -5.0F, 1, 1, 1, 0.0F, false));
            this.armorHead.field_78804_l.add(new ModelBox(this.armorHead, 0, 0, -1.0F, -13.0F, -1.0F, 2, 3, 2, 0.0F, false));
            this.cube_r1 = new ModelRenderer(this);
            this.cube_r1.func_78793_a(0.0F, 0.0F, 0.0F);
            this.armorHead.func_78792_a(this.cube_r1);
            setRotationAngle(this.cube_r1, -0.2618F, 0.0F, 0.0F);
            this.cube_r1.field_78804_l.add(new ModelBox(this.cube_r1, 55, 23, -1.0F, -16.0F, -6.0F, 2, 1, 7, 0.0F, false));
            this.cube_r1.field_78804_l.add(new ModelBox(this.cube_r1, 45, 0, -1.0F, -15.0F, -7.0F, 2, 1, 9, 0.0F, false));
            this.cube_r2 = new ModelRenderer(this);
            this.cube_r2.func_78793_a(0.0F, 0.0F, 0.0F);
            this.armorHead.func_78792_a(this.cube_r2);
            setRotationAngle(this.cube_r2, -0.2618F, 0.0F, 0.0F);
            this.cube_r2.field_78804_l.add(new ModelBox(this.cube_r2, 0, 22, -1.0F, -14.0F, -8.0F, 2, 2, 11, 0.0F, false));
            this.armorBody = new ModelRenderer(this);
            this.armorBody.func_78793_a(0.0F, 0.0F, 0.0F);
            this.armorBody.field_78804_l.add(new ModelBox(this.armorBody, 0, 36, -5.0F, 0.0F, -4.0F, 10, 12, 2, 0.0F, false));
            this.armorBody.field_78804_l.add(new ModelBox(this.armorBody, 27, 22, -5.0F, 0.0F, 2.0F, 10, 12, 2, 0.0F, false));
            this.armorBody.field_78804_l.add(new ModelBox(this.armorBody, 46, 45, -6.0F, 5.0F, -4.0F, 1, 7, 8, 0.0F, false));
            this.armorBody.field_78804_l.add(new ModelBox(this.armorBody, 44, 29, 5.0F, 5.0F, -4.0F, 1, 7, 8, 0.0F, false));
            this.armorLeftArm = new ModelRenderer(this);
            this.armorLeftArm.func_78793_a(-4.0F, 2.0F, 0.0F);
            this.armorLeftArm.field_78804_l.add(new ModelBox(this.armorLeftArm, 17, 55, -5.0F, -3.0F, -3.0F, 4, 1, 6, 0.0F, false));
            this.armorLeftArm.field_78804_l.add(new ModelBox(this.armorLeftArm, 59, 55, -5.0F, -2.0F, -3.0F, 1, 2, 6, 0.0F, false));
            this.armorLeftArm.field_78804_l.add(new ModelBox(this.armorLeftArm, 16, 22, -5.0F, 4.0F, -2.0F, 1, 5, 4, 0.0F, false));
            this.armorLeftArm.field_78804_l.add(new ModelBox(this.armorLeftArm, 45, 3, -4.0F, -2.0F, 2.0F, 3, 2, 1, 0.0F, false));
            this.armorLeftArm.field_78804_l.add(new ModelBox(this.armorLeftArm, 25, 41, -4.0F, -2.0F, -3.0F, 3, 2, 1, 0.0F, false));
            this.armorRightArm = new ModelRenderer(this);
            this.armorRightArm.func_78793_a(4.0F, 2.0F, 0.0F);
            this.armorRightArm.field_78804_l.add(new ModelBox(this.armorRightArm, 50, 15, 1.0F, -3.0F, -3.0F, 4, 1, 6, 0.0F, false));
            this.armorRightArm.field_78804_l.add(new ModelBox(this.armorRightArm, 59, 0, 4.0F, -2.0F, -3.0F, 1, 2, 6, 0.0F, false));
            this.armorRightArm.field_78804_l.add(new ModelBox(this.armorRightArm, 25, 37, 1.0F, -2.0F, 2.0F, 3, 2, 1, 0.0F, false));
            this.armorRightArm.field_78804_l.add(new ModelBox(this.armorRightArm, 0, 6, 1.0F, -2.0F, -3.0F, 3, 2, 1, 0.0F, false));
            this.armorRightArm.field_78804_l.add(new ModelBox(this.armorRightArm, 0, 22, 4.0F, 4.0F, -2.0F, 1, 5, 4, 0.0F, false));
            this.armorLeftLeg = new ModelRenderer(this);
            this.armorLeftLeg.func_78793_a(-2.0F, 12.0F, 0.0F);
            this.armorLeftLeg.field_78804_l.add(new ModelBox(this.armorLeftLeg, 0, 67, -3.0F, 0.0F, 2.0F, 5, 2, 2, 0.0F, false));
            this.armorLeftLeg.field_78804_l.add(new ModelBox(this.armorLeftLeg, 69, 69, -1.0F, 4.0F, 2.0F, 3, 1, 2, 0.0F, false));
            this.armorLeftLeg.field_78804_l.add(new ModelBox(this.armorLeftLeg, 54, 11, -1.0F, 4.0F, -4.0F, 3, 1, 2, 0.0F, false));
            this.armorLeftLeg.field_78804_l.add(new ModelBox(this.armorLeftLeg, 65, 11, -4.0F, 2.0F, 2.0F, 6, 2, 2, 0.0F, false));
            this.armorLeftLeg.field_78804_l.add(new ModelBox(this.armorLeftLeg, 64, 64, -4.0F, 2.0F, -4.0F, 6, 2, 2, 0.0F, false));
            this.armorLeftLeg.field_78804_l.add(new ModelBox(this.armorLeftLeg, 66, 66, -3.0F, 6.0F, -4.0F, 5, 5, 8, 0.0F, false));
            this.armorRightLeg = new ModelRenderer(this);
            this.armorRightLeg.func_78793_a(2.0F, 12.0F, 0.0F);
            this.armorRightLeg.field_78804_l.add(new ModelBox(this.armorRightLeg, 0, 70, -1.0F, 0.0F, 2.0F, 5, 2, 2, 0.0F, false));
            this.armorRightLeg.field_78804_l.add(new ModelBox(this.armorRightLeg, 68, 0, 0.0F, 4.0F, 2.0F, 3, 1, 2, 0.0F, false));
            this.armorRightLeg.field_78804_l.add(new ModelBox(this.armorRightLeg, 59, 3, 0.0F, 4.0F, -4.0F, 3, 1, 2, 0.0F, false));
            this.armorRightLeg.field_78804_l.add(new ModelBox(this.armorRightLeg, 66, 66, -2.0F, 2.0F, 2.0F, 6, 2, 2, 0.0F, false));
            this.armorRightLeg.field_78804_l.add(new ModelBox(this.armorRightLeg, 68, 66, -2.0F, 2.0F, -4.0F, 6, 2, 2, 0.0F, false));
            this.armorRightLeg.field_78804_l.add(new ModelBox(this.armorRightLeg, 69, 69, -1.0F, 6.0F, -4.0F, 5, 5, 8, 0.0F, false));
            this.armorLeftBoot = new ModelRenderer(this);
            this.armorLeftBoot.func_78793_a(-2.0F, 12.0F, 0.0F);
            this.armorLeftBoot.field_78804_l.add(new ModelBox(this.armorLeftBoot, 24, 53, -3.0F, 10.0F, -4.0F, 5, 2, 10, 0.0F, false));
            this.armorLeftBoot.field_78804_l.add(new ModelBox(this.armorLeftBoot, 51, 53, -3.0F, 8.0F, -4.0F, 5, 2, 2, 0.0F, false));
            this.armorRightBoot = new ModelRenderer(this);
            this.armorRightBoot.func_78793_a(2.0F, 12.0F, 0.0F);
            this.armorRightBoot.field_78804_l.add(new ModelBox(this.armorRightBoot, 51, 0, -1.0F, 10.0F, -4.0F, 5, 2, 10, 0.0F, false));
            this.armorRightBoot.field_78804_l.add(new ModelBox(this.armorRightBoot, 52, 40, -1.0F, 8.0F, -4.0F, 5, 2, 2, 0.0F, false));
        }

        @Override
        public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
            armorHead.func_78785_a(f5);
            armorBody.func_78785_a(f5);
            armorLeftArm.func_78785_a(f5);
            armorRightArm.func_78785_a(f5);
            armorLeftLeg.func_78785_a(f5);
            armorRightLeg.func_78785_a(f5);
            armorLeftBoot.func_78785_a(f5);
            armorRightBoot.func_78785_a(f5);
        }

        public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }

        @Override
        public void func_78087_a(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
            this.armorRightArm.field_78795_f = MathHelper.func_76134_b(f * 0.6662F + (float)Math.PI) * f1;
            this.armorLeftArm.field_78795_f = MathHelper.func_76134_b(f * 0.6662F) * f1;
            this.armorRightLeg.field_78795_f = MathHelper.func_76134_b(f * 0.6662F) * f1;
            this.armorLeftLeg.field_78795_f = MathHelper.func_76134_b(f * 0.6662F + (float)Math.PI) * f1;
            this.armorHead.field_78796_g = f3 * 0.017453292F; // yaw
            this.armorHead.field_78795_f = f4 * 0.017453292F; // pitch
            this.armorBody.field_78795_f = MathHelper.func_76126_a(f2 * 0.1F) * 0.05F;
            if (!e.field_70122_E && e.field_70181_x > 0) {
                this.armorRightArm.field_78795_f = -1.0F;
                this.armorLeftArm.field_78795_f = -1.0F;
            }
        }
    }
}
