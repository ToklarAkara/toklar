package net.mcreator.toklar.tile;

import java.util.List;
import java.util.Set;

import com.mujmajnkraft.bettersurvival.items.ItemCustomWeapon;

import net.mcreator.toklar.imbuement.WeaponImbuementHandler;
import net.mcreator.toklar.util.LycanitePartEffectRegistry;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumParticleTypes;

public class TileEntityImbuementAltar extends TileEntity implements IInventory, ITickable {

    private NonNullList<ItemStack> inventory = NonNullList.func_191197_a(4, ItemStack.field_190927_a);
    private int imbuementTimer = 0;
    private static final int IMBUEMENT_DELAY = 0;


    private String pendingImbuementType = null;

    @Override
    public void func_73660_a() {
        if (field_145850_b.field_72995_K) return;
      //  System.out.println("[Toklar] update() ticked");
        ItemStack weapon = inventory.get(0);
        ItemStack part = inventory.get(1);
        ItemStack catalyst = inventory.get(2);

        if (!isValidWeapon(weapon) || !isValidMonsterPart(part) || !isValidCatalyst(catalyst)) {
            imbuementTimer = 0;
            clearPreview();
        //    if (!isValidWeapon(weapon)) System.out.println("[Toklar] Weapon invalid");
         //   if (!isValidMonsterPart(part)) System.out.println("[Toklar] Monster part invalid");
         //   if (!isValidCatalyst(catalyst)) System.out.println("[Toklar] Catalyst invalid");
            return;
        }

        imbuementTimer++;

        if (imbuementTimer % 10 == 0) {
            field_145850_b.func_175688_a(EnumParticleTypes.ENCHANTMENT_TABLE,
                field_174879_c.func_177958_n() + 0.5 + (field_145850_b.field_73012_v.nextDouble() - 0.5),
                field_174879_c.func_177956_o() + 1.2,
                field_174879_c.func_177952_p() + 0.5 + (field_145850_b.field_73012_v.nextDouble() - 0.5),
                0, 0.1, 0);
        }

        if (imbuementTimer >= IMBUEMENT_DELAY) {
            ItemStack currentPreview = inventory.get(3);
 

            if (currentPreview.func_190926_b() || !ItemStack.func_179545_c(currentPreview, weapon)) {
                generatePreview();
            }

            imbuementTimer = 0;
        }
    }

    private void generatePreview() {
        ItemStack weapon = inventory.get(0);
        ItemStack part = inventory.get(1);
        ItemStack catalyst = inventory.get(2);

        if (!isValidWeapon(weapon) || !isValidMonsterPart(part) || !isValidCatalyst(catalyst)) return;

        String itemId = part.func_77973_b().getRegistryName().func_110623_a();
        NBTTagCompound partTag = part.func_77978_p();
        int partLevel = (partTag != null && partTag.func_74764_b("equipmentLevel")) ? partTag.func_74762_e("equipmentLevel") : 1;

        List<LycanitePartEffectRegistry.ImbuementEffect> effects = LycanitePartEffectRegistry.getEffectsFor(itemId);
        if (effects.isEmpty()) return;

        ItemStack currentPreview = inventory.get(3);
        if (currentPreview.func_190926_b() || !ItemStack.func_179545_c(currentPreview, weapon)) {
            ItemStack preview = weapon.func_77946_l();
            NBTTagCompound previewTag = preview.func_190925_c("toklar_imbuement");
            NBTTagList effectList = new NBTTagList();

            for (LycanitePartEffectRegistry.ImbuementEffect effect : effects) {
                if (!effect.appliesToLevel(partLevel)) continue;

                NBTTagCompound singleEffect = new NBTTagCompound();
                singleEffect.func_74778_a("effect", effect.type);
                singleEffect.func_74768_a("amplifier", effect.strength);
                singleEffect.func_74768_a("duration", effect.duration);
                singleEffect.func_74778_a("target", effect.target);
                effectList.func_74742_a(singleEffect);
            }

            if (effectList.func_74745_c() > 0) {
                previewTag.func_74782_a("effects", effectList);
                inventory.set(3, preview);
                func_70296_d();
                field_145850_b.func_184138_a(field_174879_c, field_145850_b.func_180495_p(field_174879_c), field_145850_b.func_180495_p(field_174879_c), 3);
            }
        }
    }



    public void applyImbuementOnPickup(ItemStack stack) {
        ItemStack part = inventory.get(1);
        ItemStack catalyst = inventory.get(2);

        if (part.func_190926_b() || catalyst.func_190926_b()) return;

        String itemId = part.func_77973_b().getRegistryName().func_110623_a();
        NBTTagCompound partTag = part.func_77978_p();
        int partLevel = (partTag != null && partTag.func_74764_b("equipmentLevel")) ? partTag.func_74762_e("equipmentLevel") : 1;

        List<LycanitePartEffectRegistry.ImbuementEffect> effects = LycanitePartEffectRegistry.getEffectsFor(itemId);
        if (effects.isEmpty()) return;

        NBTTagCompound imbueTag = stack.func_190925_c("toklar_imbuement");
        NBTTagList effectList = new NBTTagList();

        for (LycanitePartEffectRegistry.ImbuementEffect effect : effects) {
            if (!effect.appliesToLevel(partLevel)) continue;

            NBTTagCompound singleEffect = new NBTTagCompound();
            singleEffect.func_74778_a("effect", effect.type);
            singleEffect.func_74768_a("amplifier", effect.strength);
            singleEffect.func_74768_a("duration", effect.duration);
            singleEffect.func_74778_a("target", effect.target);
            effectList.func_74742_a(singleEffect);
        }

        imbueTag.func_74782_a("effects", effectList);

        inventory.set(3, stack); // Replace preview with imbued weapon
        inventory.set(0, ItemStack.field_190927_a);
        inventory.set(1, ItemStack.field_190927_a);
        inventory.set(2, ItemStack.field_190927_a);

        field_145850_b.func_184133_a(null, field_174879_c, SoundEvents.field_190021_aL, SoundCategory.BLOCKS, 1.0F, 1.0F);
        func_70296_d();
    }


    public ItemStack getPreviewOutput() {
        return inventory.get(3);
    
    }

    public String getPendingImbuementType() {
        return pendingImbuementType;
    }

    public void clearPreview() {
        inventory.set(3, ItemStack.field_190927_a);
        pendingImbuementType = null;
        func_70296_d();
    }


    public void dropInventory(World world, BlockPos pos) {
        for (ItemStack stack : inventory) {
            if (!stack.func_190926_b()) {
                world.func_72838_d(new EntityItem(world, pos.func_177958_n() + 0.5, pos.func_177956_o() + 1, pos.func_177952_p() + 0.5, stack));
            }
        }
    }

    // IInventory methods
    @Override public int func_70302_i_() { return inventory.size(); }
    @Override public boolean func_191420_l() { return inventory.stream().allMatch(ItemStack::func_190926_b); }
    @Override public ItemStack func_70301_a(int index) { return inventory.get(index); }
    @Override public ItemStack func_70298_a(int index, int count) { return ItemStackHelper.func_188382_a(inventory, index, count); }
    @Override public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a(inventory, index); }
    @Override public void func_70299_a(int index, ItemStack stack) {
        inventory.set(index, stack);
        if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());
        func_70296_d();
    }
    @Override public int func_70297_j_() { return 64; }
    @Override public boolean func_70300_a(EntityPlayer player) {
        return field_145850_b.func_175625_s(field_174879_c) == this && player.func_174818_b(field_174879_c) <= 64;
    }
    @Override public void func_174889_b(EntityPlayer player) {}
    @Override public void func_174886_c(EntityPlayer player) {}
    @Override public boolean func_94041_b(int index, ItemStack stack) { return true; }
    @Override public int func_174887_a_(int id) { return 0; }
    @Override public void func_174885_b(int id, int value) {}
    @Override public int func_174890_g() { return 0; }
    @Override public void func_174888_l() { inventory.clear(); }

    // IWorldNameable methods
    @Override public String func_70005_c_() { return "container.imbuement_altar"; }
    @Override public boolean func_145818_k_() { return false; }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound) {
    	compound.func_74778_a("PendingImbuementType", pendingImbuementType == null ? "" : pendingImbuementType);
        super.func_189515_b(compound);
        ItemStackHelper.func_191282_a(compound, inventory);
        compound.func_74768_a("ImbuementTimer", imbuementTimer);
        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound) {
    	compound.func_74778_a("PendingImbuementType", pendingImbuementType == null ? "" : pendingImbuementType);
    	String type = compound.func_74779_i("PendingImbuementType");
    	pendingImbuementType = type.isEmpty() ? null : type;
        super.func_145839_a(compound);
        inventory = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a);
        ItemStackHelper.func_191283_b(compound, inventory);
        imbuementTimer = compound.func_74762_e("ImbuementTimer");
    }

    public boolean isValidWeapon(ItemStack stack) {
        if (stack.func_190926_b()) return false;

        return stack.func_77973_b() instanceof net.minecraft.item.ItemSword
            || stack.func_77973_b() instanceof net.minecraft.item.ItemAxe
            || stack.func_77973_b() instanceof ItemCustomWeapon;
    }

    public boolean isValidMonsterPart(ItemStack stack) {
        if (stack.func_190926_b()) return false;
        String itemId = stack.func_77973_b().getRegistryName().func_110623_a();
        return LycanitePartEffectRegistry.hasEffects(itemId);
    }



    public static boolean isValidCatalyst(ItemStack stack) {
        if (stack.func_190926_b()) return false;
        ResourceLocation id = stack.func_77973_b().getRegistryName();
        return id != null &&
               id.func_110624_b().equals("lycanitesmobs") &&
               id.func_110623_a().contains("charge");
    }
    
    @Override
    public SPacketUpdateTileEntity func_189518_D_() {
        NBTTagCompound tag = new NBTTagCompound();
        func_189515_b(tag);
        return new SPacketUpdateTileEntity(this.field_174879_c, 1, tag);
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        func_145839_a(pkt.func_148857_g());
    }
}