package net.mcreator.toklar.block;

import java.util.List;
import java.util.Random;

import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.EntityLiving.SpawnPlacementType;
import net.minecraft.init.SoundEvents;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.WeightedRandom;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;
import net.minecraft.util.ITickable;

public class TileEntityMonsterCandle extends TileEntity implements ITickable {
    private static final int SPAWN_RADIUS = 16;
    private static final int MAX_NEARBY_MOBS = 20;
    private static final int TICKS_PER_SPAWN = 100;
    private static final int MAX_TOTAL_SPAWNS = 50;

    private int tickCounter = 0;
    private int totalSpawns = 0;

    @Override
    public void func_73660_a() {
        if (field_145850_b.field_72995_K || !(field_145850_b instanceof WorldServer)) return;
        tickCounter++;
        if (tickCounter >= TICKS_PER_SPAWN) {
            tickCounter = 0;
            triggerNaturalSpawn((WorldServer) field_145850_b, field_174879_c, field_145850_b.field_73012_v);
        }
    }

    private void triggerNaturalSpawn(WorldServer world, BlockPos pos, Random rand) {
        AxisAlignedBB area = new AxisAlignedBB(pos).func_186662_g(SPAWN_RADIUS);
        List<EntityLivingBase> nearby = world.func_72872_a(EntityLivingBase.class, area);
        if (nearby.size() >= MAX_NEARBY_MOBS) {
          //  System.out.println("Spawn blocked: too many nearby entities (" + nearby.size() + ")");
            return;
        }

        Biome biome = world.func_180494_b(pos);
        List<Biome.SpawnListEntry> spawnList = biome.func_76747_a(EnumCreatureType.MONSTER);
        if (spawnList.isEmpty()) {
          //  System.out.println("Spawn blocked: biome has no MONSTER entries");
            return;
        }

        Biome.SpawnListEntry entry = WeightedRandom.func_76271_a(rand, spawnList);
        if (entry == null || entry.field_76300_b == null) {
         //   System.out.println("Spawn blocked: no valid spawn entry selected");
            return;
        }

       // System.out.println("Attempting to spawn: " + entry.entityClass.getSimpleName());

        try {
            EntityLiving entity = (EntityLiving) entry.field_76300_b
                .getConstructor(World.class)
                .newInstance(world);

            SpawnPlacementType placement;
            if (EntityWaterMob.class.isAssignableFrom(entry.field_76300_b)) {
                placement = SpawnPlacementType.IN_WATER;
            } else if (EntityFlying.class.isAssignableFrom(entry.field_76300_b)) {
                placement = SpawnPlacementType.IN_AIR;
            } else {
                placement = SpawnPlacementType.ON_GROUND;
            }

            for (int attempt = 0; attempt < 10; attempt++) {
                int dx = rand.nextInt(SPAWN_RADIUS * 2 + 1) - SPAWN_RADIUS;
                int dz = rand.nextInt(SPAWN_RADIUS * 2 + 1) - SPAWN_RADIUS;

                BlockPos spawnPos = null;

                if (placement == SpawnPlacementType.ON_GROUND) {
                    BlockPos base = world.func_175672_r(pos.func_177982_a(dx, 0, dz));
                    spawnPos = base.func_177981_b(rand.nextInt(4));
                } else if (placement == SpawnPlacementType.IN_WATER) {
                    for (int y = pos.func_177956_o(); y > 5; y--) {
                        BlockPos check = new BlockPos(pos.func_177958_n() + dx, y, pos.func_177952_p() + dz);
                        if (world.func_180495_p(check).func_185904_a().func_76224_d()) {
                            spawnPos = check;
                            break;
                        }
                    }
                } else if (placement == SpawnPlacementType.IN_AIR) {
                    for (int y = pos.func_177956_o(); y < world.func_72940_L(); y++) {
                        BlockPos check = new BlockPos(pos.func_177958_n() + dx, y, pos.func_177952_p() + dz);
                        if (world.func_175623_d(check) && world.func_175623_d(check.func_177977_b())) {
                            spawnPos = check;
                            break;
                        }
                    }
                }

                if (spawnPos == null) {
                 //   System.out.println("Attempt " + attempt + ": No valid spawn position found for placement type " + placement);
                    continue;
                }

                double x = spawnPos.func_177958_n() + 0.5;
                double y = spawnPos.func_177956_o();
                double z = spawnPos.func_177952_p() + 0.5;

                entity.func_70012_b(x, y, z, rand.nextFloat() * 360F, 0);
                entity.field_98038_p = true;
                entity.func_110163_bv();

                boolean notInsideBlock = entity.func_70058_J();
                boolean canSpawnHere = entity.func_70601_bi();

               // System.out.println("Attempt " + attempt + ": spawnPos=" + spawnPos +
                             //      ", colliding=" + !notInsideBlock +
                              //     ", canSpawnHere=" + canSpawnHere);

                if (notInsideBlock && canSpawnHere) {
                    entity.func_180482_a(world.func_175649_E(spawnPos), null);
                    world.func_72838_d(entity);
                    totalSpawns++;

                    //System.out.println("Spawned " + entry.entityClass.getSimpleName() + " at " + spawnPos);

                    world.func_175739_a(EnumParticleTypes.SMOKE_LARGE, x, y, z, 6, 0.1, 0.1, 0.1, 0.01);
                    world.func_184148_a(null, x, y, z, SoundEvents.field_187899_gZ, SoundCategory.HOSTILE, 0.5F, 1.0F);

                    if (totalSpawns >= MAX_TOTAL_SPAWNS) {
                        world.func_175698_g(pos);
                        world.func_184133_a(null, pos, SoundEvents.field_187646_bt, SoundCategory.BLOCKS, 1.0F, 1.0F);
                        world.func_175739_a(EnumParticleTypes.SMOKE_LARGE, pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, 12, 0.2, 0.2, 0.2, 0.01);
                      //  System.out.println("Candle extinguished after max spawns");
                    }
                    break;
                } else {
                    //System.out.println("Attempt " + attempt + ": spawn blocked by collision or getCanSpawnHere()");
                }
            }
        } catch (Exception e) {
            //System.out.println("Spawn failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound) {
        super.func_189515_b(compound);
        compound.func_74768_a("TickCounter", tickCounter);
        compound.func_74768_a("TotalSpawns", totalSpawns);
        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound) {
        super.func_145839_a(compound);
        tickCounter = compound.func_74762_e("TickCounter");
        totalSpawns = compound.func_74762_e("TotalSpawns");
    }
}