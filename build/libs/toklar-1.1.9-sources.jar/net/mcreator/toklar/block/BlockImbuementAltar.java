package net.mcreator.toklar.block;

import net.mcreator.toklar.tile.TileEntityImbuementAltar;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumFacing;

public class BlockImbuementAltar extends BlockContainer {

	public BlockImbuementAltar() {
	    super(Material.field_151576_e);
	    this.func_149663_c("imbuement_altar");
	    this.func_149711_c(3.0F);
	    this.func_149752_b(10.0F);
	    this.setHarvestLevel("pickaxe", 1);
	    this.func_149715_a(0.5F);
	}

    @Override
    public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state,
                                    EntityPlayer playerIn, EnumHand hand, EnumFacing facing,
                                    float hitX, float hitY, float hitZ) {
    	System.out.println("Imbuement Altar was right-clicked");
        if (!worldIn.field_72995_K) {
            playerIn.openGui(net.mcreator.toklar.Toklar.instance,
                             net.mcreator.toklar.gui.GuiHandler.IMBUEMENT_ALTAR_GUI_ID,
                             worldIn, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
        }
        return true;
    }
    @Override
    public TileEntity func_149915_a(World worldIn, int meta) {
        return new TileEntityImbuementAltar();
    }

    @Override
    public EnumBlockRenderType func_149645_b(IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }

    @Override
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.SOLID;
    }

    @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    @Override
    public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
        TileEntity tile = worldIn.func_175625_s(pos);
        if (tile instanceof TileEntityImbuementAltar) {
            ((TileEntityImbuementAltar) tile).dropInventory(worldIn, pos);
        }
        super.func_180663_b(worldIn, pos, state);
    }
}