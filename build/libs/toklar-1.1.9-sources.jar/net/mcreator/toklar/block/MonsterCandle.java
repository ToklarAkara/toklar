package net.mcreator.toklar.block;

import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class MonsterCandle extends Block implements ITileEntityProvider {
    public MonsterCandle() {
        super(Material.field_151576_e);
        this.func_149711_c(1.5F);
        this.func_149752_b(10F);
    }
    @Override
    public boolean func_149662_c(IBlockState state) {
        return false;
    }

    @Override
    public boolean func_149686_d(IBlockState state) {
        return false;
    }
    @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    // Required by ITileEntityProvider in 1.12.2
    @Override
    public TileEntity func_149915_a(World worldIn, int meta) {
        return new TileEntityMonsterCandle();
    }
}