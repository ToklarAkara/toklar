package net.mcreator.toklar.gui;

import net.mcreator.toklar.tile.TileEntityImbuementAltar;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class SlotImbuementOutput extends Slot {
    private final TileEntityImbuementAltar altar;

    public SlotImbuementOutput(TileEntityImbuementAltar altar, IInventory inventory, int index, int xPosition, int yPosition) {
        super(inventory, index, xPosition, yPosition);
        this.altar = altar;
    }
    @Override
    public ItemStack func_75211_c() {
        return altar.getPreviewOutput().func_77946_l();
    
    }
    @Override
    public boolean func_75214_a(ItemStack stack) {
        return false; // Prevent inserting items into output slot
    }
    @Override
    public ItemStack func_75209_a(int amount) {
        ItemStack result = altar.getPreviewOutput().func_77946_l();
        altar.clearPreview(); 
        return result;
    }
    @Override
    public ItemStack func_190901_a(EntityPlayer player, ItemStack stack) {
        altar.applyImbuementOnPickup(stack);
        return stack;
    }
}