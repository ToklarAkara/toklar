package net.mcreator.toklar.gui;

import net.mcreator.toklar.tile.TileEntityImbuementAltar;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiImbuementAltar extends GuiContainer {

    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation("toklar:textures/gui/imbuement_altar.png");
    private final TileEntityImbuementAltar altar;

    public GuiImbuementAltar(TileEntityImbuementAltar altar, InventoryPlayer playerInv) {
        super(new ContainerImbuementAltar(altar, playerInv));
        this.altar = altar;
        this.field_146999_f = 176;
        this.field_147000_g = 166;
    
    }

    @Override
    protected void func_146979_b(int mouseX, int mouseY) {
        ItemStack preview = altar.getPreviewOutput();
        String effect = altar.getPendingImbuementType();

        // Fallback: extract effect from preview item NBT if needed
        if ((effect == null || effect.isEmpty()) && preview.func_77942_o()) {
            NBTTagCompound tag = preview.func_179543_a("toklar_imbuement");
            if (tag != null && tag.func_74764_b("effect")) {
                effect = tag.func_74779_i("effect");
            }
        }

        if (effect != null && !effect.isEmpty()) {
            int slotX = 125;
            int slotY = 31;
            int relX = mouseX - this.field_147003_i;
            int relY = mouseY - this.field_147009_r;

            if (relX >= slotX && relX < slotX + 18 && relY >= slotY && relY < slotY + 18) {
                this.func_146279_a("Imbuement: " + effect, relX, relY);
            }
        }

        // Static label in top-right corner
        this.field_146289_q.func_78276_b("Imbuement", this.field_146999_f - 54, 6, 0x404040);
    }
    

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_(); // Fixes the missing dark backdrop
        super.func_73863_a(mouseX, mouseY, partialTicks);

        // Prevent default rendering of slot 3 (commented out for stability)
        // if (this.inventorySlots.getSlot(3) != null) {
        //     this.inventorySlots.getSlot(3).putStack(ItemStack.EMPTY);
        // }

        this.func_191948_b(mouseX, mouseY);
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURE);
        int x = (this.field_146294_l - this.field_146999_f) / 2;
        int y = (this.field_146295_m - this.field_147000_g) / 2;
        this.func_73729_b(x, y, 0, 0, this.field_146999_f, this.field_147000_g);

        //  Manually render scaled preview item

            ItemStack preview = altar.getPreviewOutput();
            if (!preview.func_190926_b()) {
                int slotX = x + 125;
                int slotY = y + 31;

                GlStateManager.func_179094_E();
                GlStateManager.func_179109_b(slotX, slotY, 0);
            //    GlStateManager.scale(1.5F, 1.5F, 1.0F);
                RenderHelper.func_74520_c();
                this.field_146296_j.func_180450_b(preview, 0, 0);
                this.field_146296_j.func_180453_a(this.field_146289_q, preview, 0, 0, null);
                RenderHelper.func_74518_a();
                GlStateManager.func_179121_F();
            }
        }
    }
