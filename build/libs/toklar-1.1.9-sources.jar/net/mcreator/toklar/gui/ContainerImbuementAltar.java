package net.mcreator.toklar.gui;

import net.mcreator.toklar.tile.TileEntityImbuementAltar;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.inventory.SlotCrafting;


public class ContainerImbuementAltar extends Container {
    private final TileEntityImbuementAltar altar;
    private final IInventory tile;

    public ContainerImbuementAltar(IInventory tile, InventoryPlayer playerInv) {
        this.tile = tile;
        this.altar = (TileEntityImbuementAltar) tile;

     // Weapon slot
        this.func_75146_a(new Slot(tile, 0, 45, 17) {
            @Override
            public boolean func_75214_a(ItemStack stack) {
                return altar.isValidWeapon(stack);
            }

            @Override
            public int func_75219_a() {
                return 1;
            }
        });

        // Monster part slot
        this.func_75146_a(new Slot(tile, 1, 67, 17) {
            @Override
            public boolean func_75214_a(ItemStack stack) {
                return altar.isValidMonsterPart(stack);
            }

            @Override
            public int func_75219_a() {
                return 1;
            }
        });

        // Catalyst slot
        this.func_75146_a(new Slot(tile, 2, 56, 53) {
            @Override
            public boolean func_75214_a(ItemStack stack) {
                return altar.isValidCatalyst(stack);
            }

            @Override
            public int func_75219_a() {
                return 1;
            }
        });

        this.func_75146_a(new SlotImbuementOutput(altar, tile, 3, 125, 31)); // Output

        // Player inventory (slots 9–35)
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 9; ++col)
                this.func_75146_a(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));

        // Hotbar (slots 0–8)
        for (int i = 0; i < 9; ++i)
            this.func_75146_a(new Slot(playerInv, i, 8 + i * 18, 142));
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return tile.func_70300_a(playerIn);
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d()) {
            ItemStack stackInSlot = slot.func_75211_c();
            itemstack = stackInSlot.func_77946_l();

            int altarSlotCount = 4;
            int playerInventoryStart = altarSlotCount;
            int playerInventoryEnd = this.field_75151_b.size();

            // If clicked slot is in altar inventory
            if (index < altarSlotCount) {
                // Prevent shift-clicking output slot
                if (index == 3) return ItemStack.field_190927_a;

                if (!this.func_75135_a(stackInSlot, playerInventoryStart, playerInventoryEnd, true))
                    return ItemStack.field_190927_a;
            } else {
                // Try to place into altar slots
                if (!this.func_75135_a(stackInSlot, 0, altarSlotCount - 1, false))
                    return ItemStack.field_190927_a;
            }

            if (stackInSlot.func_190926_b()) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }
        }

        return itemstack;
    }
}